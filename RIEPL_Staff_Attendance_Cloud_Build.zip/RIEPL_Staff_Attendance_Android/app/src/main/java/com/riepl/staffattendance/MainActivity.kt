package com.riepl.staffattendance

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.*
import android.view.Gravity
import android.graphics.Color
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val green = Color.rgb(23,107,58)
    private val prefs by lazy { getSharedPreferences("riepl_records", Context.MODE_PRIVATE) }
    private val staff = listOf(
        "RIEPL001 - Sagar Malick",
        "RIEPL002 - Sunakr Mallick",
        "RIEPL003 - Ratnakr Mallick",
        "RIEPL004 - Ankit Singh"
    )
    private var selectedStaff = staff[0]
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var locationText = "Not captured"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(242,247,242))
        }
        val head = TextView(this).apply {
            text = "REDIFINE IMAGINATION ENGINEERING PVT LTD\n$title"
            textSize = 19f; setTextColor(Color.WHITE); setPadding(18,22,18,22)
            setBackgroundColor(green); gravity = Gravity.CENTER
        }
        root.addView(head)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label; setTextColor(Color.WHITE); setBackgroundColor(green)
            textSize = 15f; setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
    }

    private fun label(value: String, size: Float = 16f) {
        root.addView(TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.rgb(24,51,35))
            setPadding(4,12,4,8)
        })
    }

    private fun showLogin() {
        base("STAFF ATTENDANCE")
        label("Select Employee ID")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, staff)
        root.addView(spinner)
        button("LOGIN") {
            selectedStaff = spinner.selectedItem.toString()
            showDashboard()
        }
        label("Demo starter: employee selection login. PIN-secured login and admin authorization must be added before live deployment.", 12f)
    }

    private fun showDashboard() {
        base("WELCOME")
        label(selectedStaff)
        status = TextView(this).apply { text = "Attendance: not marked"; textSize = 16f; setTextColor(Color.BLACK) }
        root.addView(status)
        button("CAPTURE GPS LOCATION") { captureLocation() }
        button("CHECK IN") { saveRecord("CHECK IN") }
        button("CHECK OUT") { saveRecord("CHECK OUT") }
        label("Staff Advance")
        val amount = EditText(this).apply { hint = "Advance amount in INR"; inputType = 2 }
        val purpose = EditText(this).apply { hint = "Purpose (travel / food / other)" }
        root.addView(amount); root.addView(purpose)
        button("SAVE ADVANCE REQUEST") {
            val value = amount.text.toString().toDoubleOrNull()
            if (value == null || value <= 0) toast("Enter a valid amount")
            else {
                saveRecord("ADVANCE REQUEST", value, purpose.text.toString())
                amount.text.clear(); purpose.text.clear()
            }
        }
        button("MY RECORDS") { showRecords(false) }
        button("ADMIN DEMO SUMMARY") { showRecords(true) }
        button("LOG OUT") { showLogin() }
        label("GPS: $locationText", 12f)
    }

    private fun captureLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 100)
            return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val loc: Location? = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            locationText = if (loc != null) "${loc.latitude}, ${loc.longitude}" else "Location unavailable; enable GPS and try again"
            toast(locationText)
        } catch (e: Exception) { toast("Could not get location: ${e.message}") }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) captureLocation()
        else toast("Location permission is required for GPS attendance")
    }

    private fun saveRecord(type: String, amount: Double? = null, purpose: String = "") {
        val arr = JSONArray(prefs.getString("records", "[]"))
        val now = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        val item = JSONObject().put("staff", selectedStaff).put("type", type)
            .put("time", now).put("location", locationText)
        if (amount != null) item.put("amount", amount).put("purpose", purpose)
        arr.put(item)
        prefs.edit().putString("records", arr.toString()).apply()
        status.text = "$type saved at $now"
        toast("$type saved on this phone")
    }

    private fun showRecords(admin: Boolean) {
        base(if (admin) "ADMIN DEMO SUMMARY" else "MY RECORDS")
        val arr = JSONArray(prefs.getString("records", "[]"))
        var shown = 0
        for (i in arr.length()-1 downTo 0) {
            val o = arr.getJSONObject(i)
            if (admin || o.optString("staff") == selectedStaff) {
                val text = "${o.optString("staff")}\n${o.optString("type")} | ${o.optString("time")}\nGPS: ${o.optString("location")}" +
                    if (o.has("amount")) "\nAdvance: ₹${o.optDouble("amount")} | ${o.optString("purpose")}" else ""
                label(text, 13f); shown++
            }
        }
        if (shown == 0) label("No records saved yet")
        button("BACK") { showDashboard() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
