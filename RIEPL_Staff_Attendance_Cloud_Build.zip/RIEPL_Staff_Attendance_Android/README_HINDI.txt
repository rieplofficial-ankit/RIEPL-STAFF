RIEPL STAFF ATTENDANCE - ANDROID STARTER PROJECT

IMPORTANT:
- This is a starter Android project, not a pre-built APK.
- It currently saves attendance/advance data locally on the same phone.
- Multiple phones do NOT share data yet. Firebase/backend and secure admin/staff authentication must be configured before company-wide live use.
- GPS uses Android location permission. For best result enable device location before capturing.
- Do not use this demo as an official payroll or attendance record until backend, access control, server timestamps and testing are added.

BUILD APK ON WINDOWS:
1. Install Android Studio (stable version) from https://developer.android.com/studio
2. Extract this ZIP to a folder, e.g. C:\RIEPL_Staff_Attendance_Android
3. Open Android Studio > Open > select the extracted project folder.
4. Allow Gradle sync and install any requested Android SDK (API 35) and JDK.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. After successful build, click Locate. APK is normally in app\build\outputs\apk\debug\app-debug.apk
7. Transfer APK to Android phone and install. Allow "Install unknown apps" only for this trusted APK.

NEXT PRODUCTION STEP:
Configure Firebase Authentication + Firestore (or another backend), add admin-only roles, employee PIN/passwords, server-side timestamp validation, location accuracy checks, data export and privacy notice. Each employee should use their own login. Never share an admin login.

APK BUILD WITHOUT ANDROID STUDIO (GITHUB CLOUD BUILD):
1. Create/sign in to a GitHub account.
2. Create a new repository named RIEPL-Staff-Attendance.
3. Upload all files and folders from this project into the repository (including the hidden .github folder).
4. Open the repository > Actions. If prompted, enable workflows.
5. Select "Build RIEPL STAFF APK" and click "Run workflow".
6. When the run finishes successfully, open that run and download the artifact named "RIEPL-STAFF-APK".
7. Extract the downloaded artifact ZIP. It contains app-debug.apk. Transfer it to the Android phone and install it.

LIMITATION: This cloud workflow only compiles the current starter/demo app. It does NOT add cloud sync or production security. Attendance/advance entries remain on the phone where they were entered. Do not deploy as a company-wide attendance system until shared backend and authentication are implemented and tested.
